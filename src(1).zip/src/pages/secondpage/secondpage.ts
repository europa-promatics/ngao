import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {Http} from '@angular/http';
import { ResultPage } from '../result/result';
/*
  Generated class for the Secondpage page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-secondpage',
  templateUrl: 'secondpage.html'
})
export class SecondpagePage {
	data;
	first_name;
	last_name;
  constructor(public http: Http,public navCtrl: NavController, public navParams: NavParams) {
  	this.data={};
  	this.data.last_name='';
  	this.data.response='';
  	
  }

  submitt()
  {
  	this.data.first_name=this.navParams.get('first_name');
  	//this.navCtrl.push(ResultPage,{first_name:this.first_name,last_name:this.data.last_name});
  	var link = 'http://europa.promaticstechnologies.com/million/webservicelogin';
    var data = JSON.stringify({email:this.data.first_name,password:this.data.last_name});
    this.http.post(link,data)
        .subscribe(data => {
          this.data.response = data;
          console.log(this.data.response);
        }, error => {
            console.log("Oooops!");
        });

  }

}
