import { Component } from '@angular/core';
import { ActionSheetController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { NavController } from 'ionic-angular';
import { SecondpagePage } from '../secondpage/secondpage';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	data;
  constructor(public navCtrl:NavController, public actionSheetController:ActionSheetController,public alertCtrl:AlertController) {
    this.data= {};
    this.data.first_name = '';

  }
  alertBox(value){
	  	if(value==1){
		    let alert = this.alertCtrl.create({
		      title: 'New Friend!',
		      subTitle: 'Your friend just accepted your friend request!',
		      buttons: ['OK']
		    });
		    alert.present();
	    }
	    if(value==2){
		    let alert = this.alertCtrl.create({
		      title: 'Login',
		      message: "Enter a name for this new album you're so keen on adding",
		      inputs: [
		        {
		          name: 'title',
		          placeholder: 'Title'
		        },
		      ],
		      buttons: [
		        {
		          text: 'Cancel',
		          handler: data => {
		            console.log('Cancel clicked');
		          }
		        },
		        {
		          text: 'Save',
		          handler: data => {
		            console.log('Saved clicked');
		          }
		        }
		      ]
		    });
	    	alert.present();
	    }
	    if(value==3){
		    let alert = this.alertCtrl.create({
		    title: 'Use this lightsaber?',
		    message: 'Do you agree to use this lightsaber to do good across the intergalactic galaxy?',
		    buttons: [
		        {
		          text: 'Disagree',
		          handler: () => {
		            console.log('Disagree clicked');
		          }
		        },
		        {
		          text: 'Agree',
		          handler: () => {
		            console.log('Agree clicked');
		          }
		        }
		      ]
		    });
		    alert.present();
	    }
	    if(value==4){
	    	let alert = this.alertCtrl.create();
		    alert.setTitle('Lightsaber color');

		    alert.addInput({
		      type: 'radio',
		      label: 'white',
		      value: 'white',
		      checked: true
		    });
		    alert.addInput({
		      type: 'radio',
		      label: 'Blue',
		      value: 'blue',
		      checked: true
		    });

		    alert.addButton('Cancel');
		    alert.addButton({
		      text: 'OK',
		      handler: data => {
		       // this.testRadioOpen = false;
		        //this.testRadioResult = data;
		      }
		    });
		    alert.present();
	    }
  }
  actionSheet(){
	    let actionSheet = this.actionSheetController.create({
	      title: 'Modify your album',
	      buttons: [
	        {
	          text: 'Destructive',
	          role: 'destructive',
	          handler: () => {
	            console.log('Destructive clicked');
	          }
	        },{
	          text: 'Archive',
	          handler: () => {
	            console.log('Archive clicked');
	          }
	        },{
	          text: 'Cancel',
	          role: 'cancel',
	          handler: () => {
	            console.log('Cancel clicked');
	          }
	        }
	      ]
	    });
	    actionSheet.present();
  }
  submit()
  {
  	this.navCtrl.push(SecondpagePage,{first_name:this.data.first_name})
  }

}
